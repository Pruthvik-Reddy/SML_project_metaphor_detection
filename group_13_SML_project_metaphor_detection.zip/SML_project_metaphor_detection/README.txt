Dataset : 
Topic: metaphor detection
� Training data: 1,870 samples
� Test data: 800 samples (unseen)

� metaphorID: ID of a metaphor candidate word (Corrected)
� 0: road
� 1: candle
� 2: light
� 3: spice
� 4: ride
� 5: train
� 6: boat
� label: binary label (TRUE: metaphorical, FALSE: literal)
� text: text that contains the metaphor candidate word. If there are multiple
occurrences of the word, the annotation is always for the first occurrence.